
const buttonClick = () => {
    document.getElementById('mainHeading').innerHTML = "Nice, you broke it!";
    document.getElementById('button').style.display = "none";
    document.getElementById('menu').style.display = "none";
}